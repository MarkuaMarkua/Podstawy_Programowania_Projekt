import java.util.ArrayList;
import java.util.List;

public class Uczen {
    String imie;
    String nazwisko;
    String numerIndeksu;
    List<Double> oceny;
    public Uczen(String imie, String nazwisko, String numerIndeksu){
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.numerIndeksu = numerIndeksu;
        this.oceny = new ArrayList<>();
    }
    public double obliczSredniaOcen() {
    if (oceny.isEmpty()) return 0.0;
    double suma = 0;
    for (double o : oceny) suma += o;
    return suma / oceny.size();
    }
    public void pokazInformacje(){
        System.out.println("Student: " + imie + " " + nazwisko + " " + ", numer indeksu: " + numerIndeksu);
        System.out.println("Oceny: " + oceny);
        System.out.println("Średnia ocen: " + obliczSredniaOcen());
    }

    public void dodajOcene(double ocena) {
        oceny.add(ocena);
    }
    public String getNumerIndeksu() {
        return numerIndeksu;
    }

}
