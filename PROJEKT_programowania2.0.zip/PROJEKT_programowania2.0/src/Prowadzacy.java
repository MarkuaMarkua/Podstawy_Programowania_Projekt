public class Prowadzacy {
    String imie;
    String nazwisko;
    String tytulNaukowy;
    public Prowadzacy(String imie, String nazwisko, String tytulNaukowy){
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.tytulNaukowy = tytulNaukowy;
    }
    public void pokazInformacje(){
        System.out.println("Prowadzący: " + imie + " " + nazwisko + " " + tytulNaukowy);
    }
}
