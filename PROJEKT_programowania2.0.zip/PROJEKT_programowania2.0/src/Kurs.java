import java.util.*;

public class Kurs {
    String nazwa;
    String kod;
    Prowadzacy prowadzacy;
    List<Uczen> uczni;
    Map<String, List<Double>> ocenyUczniow;

    public Kurs(String nazwa, String kod, Prowadzacy prowadzacy) {
        this.nazwa = nazwa;
        this.kod = kod;
        this.prowadzacy = prowadzacy;
        this.uczni = new ArrayList<>();
        this.ocenyUczniow = new HashMap<>();
    }

    public void dodajUcznia(Uczen uczen) {
        if (!uczni.contains(uczen)) {
            uczni.add(uczen);
            ocenyUczniow.put(uczen.numerIndeksu, new ArrayList<>());
        }
    }

    public void dodajOcene(Uczen uczen, double ocena) {
        List<Double> oceny = ocenyUczniow.get(uczen.numerIndeksu);
        if (oceny != null) {
            oceny.add(ocena);
            uczen.dodajOcene(ocena);
        }
    }

    public double obliczSredniaKursu() {
        int liczbaOcen = 0;
        double suma = 0;
        for (List<Double> listaOcen : ocenyUczniow.values()) {
            for (double ocena : listaOcen) {
                suma += ocena;
                liczbaOcen++;
            }
        }
        return liczbaOcen == 0 ? 0 : suma / liczbaOcen;
    }

    public void pokazInformacje() {
        System.out.println("Kurs: " + nazwa + " (" + kod + ")");
        prowadzacy.pokazInformacje();
        System.out.println("Średnia ocen na kursie: " + obliczSredniaKursu());
        System.out.println("Zapisani Uczni:");
        for (Uczen uczen : uczni) {
            System.out.println("- " + uczen.getNumerIndeksu() + ": " + ocenyUczniow.get(uczen.getNumerIndeksu()));
        }
    }
}
