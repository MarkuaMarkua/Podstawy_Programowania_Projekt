public class Main {
    public static void dodajUczniaDoKursu(Uczen uczen, Kurs kurs){
        kurs.dodajUcznia(uczen);
    }
    public static void przypiszOcene(Uczen uczen, Kurs kurs, double ocena) {
        kurs.dodajOcene(uczen,ocena);
    }
    public static void main(String[] args) {
        Prowadzacy prow1 = new Prowadzacy("John", "Dow", "Inż");
        Kurs kurs1 = new Kurs("Podstawy Programowania", "0001", prow1);

        Uczen uczen1 = new Uczen("Mark", "Kopanytsia", "91489");
        Uczen uczen2 = new Uczen("Jimmy", "Brown", "98419");

        dodajUczniaDoKursu(uczen1, kurs1);
        dodajUczniaDoKursu(uczen2, kurs1);

        przypiszOcene(uczen1,kurs1,5.0);
        przypiszOcene(uczen1,kurs1,3.0);
        przypiszOcene(uczen2,kurs1,3.0);

        kurs1.pokazInformacje();
        System.out.println();

        uczen1.pokazInformacje();
        System.out.println();

        uczen2.pokazInformacje();
    }
}