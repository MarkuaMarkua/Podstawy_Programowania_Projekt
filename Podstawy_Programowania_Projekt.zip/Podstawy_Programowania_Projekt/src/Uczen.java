public class Uczen {
    String imie;
    String nazwisko;
    int[] oceny;

    public Uczen(String imie, String nazwisko, int[] oceny) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.oceny = oceny;
    }

    public void PokazOceny() {
        System.out.println("Uczeń: " + imie + " " + nazwisko);
        System.out.print("Oceny: ");
        for (int ocena : oceny) {
            System.out.print(ocena + " ");
        }
        System.out.println();
    }
}
