public class Main {
    public static double obliczSrednia(Uczen uczen) {
        int suma = 0;
        for (int ocena : uczen.oceny) {
            suma += ocena;
        }
        return (double) suma / uczen.oceny.length;
    }

    public static void main(String[] args) {
        Uczen uczen1 = new Uczen("Jan", "Kowalski", new int[]{5, 4, 3, 5});
        uczen1.PokazOceny();

        double srednia = obliczSrednia(uczen1);
        System.out.println("Średnia ocen: " + srednia);
    }
}
